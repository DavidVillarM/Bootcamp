function hide(e) {
    e.remove();
}

function logOut(e) {
    e.innerText = "LogOut"
}